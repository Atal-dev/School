import React from 'react';
import { Provider } from 'react-redux';
import { store } from './redux/store';
import Sidebar from './components/Sidebar';
import MainContent from './components/MainContent';
import Navbar from './components/Navbar';
import './App.css'

function App() {
  return (
    <Provider store={store}>
      <div className="App">
        <Navbar />
        <div className="dashboard">
          <Sidebar />
          <MainContent />
        </div>
      </div>
    </Provider>
  );
}

export default App;
