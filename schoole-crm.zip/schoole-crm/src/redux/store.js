import { configureStore } from '@reduxjs/toolkit';
import dashboardReducer from '../redux/dashboardSlice';
import studentReducer from '../redux/studentsSlice';
import teacherReducer from '../redux/teacherSlice';



export const store = configureStore({
  reducer: {
    dashboard: dashboardReducer,
    student:studentReducer,
    teacher: teacherReducer,


  },
});
