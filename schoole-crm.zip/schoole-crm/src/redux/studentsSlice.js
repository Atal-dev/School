import { createSlice } from '@reduxjs/toolkit';

// Sample data for students by class and section, each with unique names and DOBs
const initialState = {
  studentsData: [
    {
      className: 'Class 1',
      classTeacher: 'Mr. Sharma',
      teacherMobile: '123-456-7890',
      sections: {
        A: [
          { id: 'A-1', name: 'Aarav Gupta', dob: '2013-05-12' },
          { id: 'A-2', name: 'Siya Kapoor', dob: '2013-10-27' },
        ],
        B: [
          { id: 'B-1', name: 'Kabir Joshi', dob: '2013-09-27' },
          { id: 'B-2', name: 'Ananya Mehra', dob: '2013-10-22' },
        ],
      },
      attendanceStatus: {
        A: {},
        B: {},
      },
    },
    {
      className: 'Class 2',
      classTeacher: 'Ms. Verma',
      teacherMobile: '234-567-8901',
      sections: {
        A: [
          { id: 'A-1', name: 'Ishaan Verma', dob: '2023-10-22' },
          { id: 'A-2', name: 'Mira Sen', dob: '2012-04-29' },
        ],
        B: [
          { id: 'B-1', name: 'Vedant Desai', dob: '2012-08-07' },
          { id: 'B-2', name: 'Sara Malhotra', dob: '2012-06-25' },
        ],
      },
      attendanceStatus: {
        A: {},
        B: {},
      },
    },
    {
      className: 'Class 3',
      classTeacher: 'Mrs. Rao',
      teacherMobile: '345-678-9012',
      sections: {
        A: [
          { id: 'A-1', name: 'Vivaan Shah', dob: '2011-12-13' },
          { id: 'A-2', name: 'Aditi Patil', dob: '2011-05-30' },
          { id: 'A-3', name: 'Aditi Patil', dob: '2011-05-30' },
          { id: 'A-4', name: 'Aditi Patil', dob: '2011-05-30' },
        ],
        B: [
          { id: 'B-1', name: 'Dhruv Yadav', dob: '2011-08-18' },
          { id: 'B-2', name: 'Naina Reddy', dob: '2011-02-23' },
        ],
        C: [
          { id: 'B-1', name: 'Dhruv Yadav', dob: '2011-08-18' },
          { id: 'B-2', name: 'Naina Reddy', dob: '2011-02-23' },
        ],
      },
      attendanceStatus: {
        A: {},
        B: {},
      },
    },
    {
      className: 'Class 4',
      classTeacher: 'Mrs. Rao',
      teacherMobile: '345-678-9012',
      sections: {
        A: [
          { id: 'A-1', name: 'Vivaan Shah', dob: '2011-12-13' },
          { id: 'A-2', name: 'Aditi Patil', dob: '2011-05-30' },
          { id: 'A-3', name: 'Aditi Patil', dob: '2011-05-30' },
          { id: 'A-4', name: 'Aditi Patil', dob: '2011-05-30' },
        ],
        
      },
      attendanceStatus: {
        A: {},
      },
    },
  ],
};

const studentsSlice = createSlice({
  name: 'students',
  initialState,
  reducers: {
    markAttendanceSubmitted: (state, action) => {
      const { className, section, date } = action.payload;
      const classData = state.studentsData.find((cls) => cls.className === className);
      if (classData) {
        if (!classData.attendanceStatus[section]) {
          classData.attendanceStatus[section] = {};
        }
        classData.attendanceStatus[section][date] = { submitted: true };
      }
    },
    addStudent: (state, action) => {
      const { className, newStudent } = action.payload;
      const classData = state.studentsData.find((cls) => cls.className === className);
      if (classData) {
        if (!classData.sections[newStudent.section]) {
          classData.sections[newStudent.section] = [];
        }
        const id = `${newStudent.section}-${classData.sections[newStudent.section].length + 1}`;
        const studentWithId = { id, ...newStudent };
        classData.sections[newStudent.section].push(studentWithId);
      }
    },
  },
});

export const { markAttendanceSubmitted, addStudent } = studentsSlice.actions;
export default studentsSlice.reducer;
