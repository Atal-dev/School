// teacherSlice.js
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  teachersData: [
    {
      id: 1,
      name: 'Mr. Sharma',
      subject: 'Math',
      qualification: 'MSc Mathematics',
      age: 40,
      experience: 15,
      assignedClass: '10th Grade',
    },
    {
      id: 2,
      name: 'Ms. Verma',
      subject: 'English',
      qualification: 'MA English',
      age: 35,
      experience: 10,
      assignedClass: '9th Grade',
    },
    {
      id: 3,
      name: 'Mr. Singh',
      subject: 'Science',
      qualification: 'MSc Physics',
      age: 45,
      experience: 20,
      assignedClass: '12th Grade',
    },
    {
      id: 4,
      name: 'Ms. Gupta',
      subject: 'History',
      qualification: 'MA History',
      age: 30,
      experience: 8,
      assignedClass: '11th Grade',
    },
    {
      id: 5,
      name: 'Mr. Nair',
      subject: 'Computer Science',
      qualification: 'MCA',
      age: 50,
      experience: 25,
      assignedClass: '12th Grade',
    },
  ],
  submittedAttendance: [], // Keeps track of dates when attendance is submitted
};

const teacherSlice = createSlice({
  name: 'teacher',
  initialState,
  reducers: {
    addTeacher: (state, action) => {
      // Add the new teacher to the teachersData array
      state.teachersData.push(action.payload);
    },
    markTeacherAttendanceSubmitted: (state, action) => {
      const { date, teacherId } = action.payload;
      // Find the teacher by ID and update attendance
      const teacher = state.teachersData.find((t) => t.id === teacherId);
      if (teacher) {
        if (!teacher.attendance) {
          teacher.attendance = {};
        }
        // Mark attendance for the specified date
        teacher.attendance[date] = true;
      }
      // Add the date to the submittedAttendance array
      state.submittedAttendance.push(date);
    },
    updateTeacher: (state, action) => {
      const { id, updatedData } = action.payload;
      // Find the teacher by ID and update their details
      const teacherIndex = state.teachersData.findIndex((t) => t.id === id);
      if (teacherIndex !== -1) {
        state.teachersData[teacherIndex] = {
          ...state.teachersData[teacherIndex],
          ...updatedData,
        };
      }
    },
    deleteTeacher: (state, action) => {
      const teacherId = action.payload;
      // Remove the teacher from the teachersData array
      state.teachersData = state.teachersData.filter((t) => t.id !== teacherId);
    },
  },
});

export const {
  addTeacher,
  markTeacherAttendanceSubmitted,
  updateTeacher,
  deleteTeacher,
} = teacherSlice.actions;

export default teacherSlice.reducer;
