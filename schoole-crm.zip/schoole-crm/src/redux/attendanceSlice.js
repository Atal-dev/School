// import { createSlice } from '@reduxjs/toolkit';

// const initialState = {
//   classes: [
//     {
//       id: 1,
//       className: "Class 1",
//       teacherName: "Mr. Smith",
//       teacherMobile: "123-456-7890",
//       submitted: false,
//     },
//     {
//       id: 2,
//       className: "Class 2",
//       teacherName: "Ms. Johnson",
//       teacherMobile: "098-765-4321",
//       submitted: false,
//     },
//     // Add more classes as needed
//   ],
// };

// const attendanceSlice = createSlice({
//   name: 'attendance',
//   initialState,
//   reducers: {
//     submitAttendance: (state, action) => {
//       const classId = action.payload;
//       const classToUpdate = state.classes.find(cls => cls.id === classId);
//       if (classToUpdate) {
//         classToUpdate.submitted = true;
//       }
//     },
//   },
// });

// export const { submitAttendance } = attendanceSlice.actions;
// export const selectClasses = (state) => state.attendance.classes;
// export default attendanceSlice.reducer;
