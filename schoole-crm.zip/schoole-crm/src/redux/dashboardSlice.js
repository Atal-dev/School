import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  activeMenu: null,          // Track which main menu is open
  activeSubmenu: null,       // Track which submenu is selected
};

const dashboardSlice = createSlice({
  name: 'dashboard',
  initialState,
  reducers: {
    setActiveMenu: (state, action) => {
      // Toggle the menu and close others
      state.activeMenu = state.activeMenu === action.payload ? null : action.payload;
    },
    setActiveSubmenu: (state, action) => {
      // Set active submenu to render corresponding component
      state.activeSubmenu = action.payload;
    },
  },
});

export const { setActiveMenu, setActiveSubmenu } = dashboardSlice.actions;
export default dashboardSlice.reducer;
