// AttendanceStatus.js
import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import '../Styles/ClassAttendanceStatus.css';

const AttendanceStatus = () => {
  const { studentsData } = useSelector(state => state.student);
  const [selectedDate, setSelectedDate] = useState('');

  const handleDateChange = (e) => {
    setSelectedDate(e.target.value);
  };

  return (
    <div className="attendance-status">
      <h2>Attendance Submission Status</h2>
      <div>
        <label>
          Select Date:
          <input type="date" value={selectedDate} onChange={handleDateChange} />
        </label>
      </div>
      <table>
        <thead>
          <tr>
            <th>Class Name</th>
            <th>Class Teacher</th>
            <th>Teacher Mobile No.</th>
            <th>Attendance Status</th>
          </tr>
        </thead>
        <tbody>
          {studentsData.map((classData) => (
            <React.Fragment key={classData.className}>
              {Object.entries(classData.attendanceStatus).map(([section, statuses]) => {
                const statusForDate = statuses[selectedDate];
                const statusText = statusForDate?.submitted ? 'Submitted' : 'Pending';
                return (
                  <tr key={`${classData.className}-${section}`}>
                    <td>{classData.className} - Section {section}</td>
                    <td>{classData.classTeacher}</td>
                    <td>{classData.teacherMobile}</td>
                    <td>{statusText}</td>
                  </tr>
                );
              })}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AttendanceStatus;
