import React from 'react';
import '../Styles/OverallAttendance.css'

const OverallAttendance = () => {
  // Mock data for demonstration
  const attendanceData = {
    totalStudents: 100,
    present: 80,
    absent: 20,
  };

  return (
    <div className="overall-attendance">
      <h3>Overall Attendance</h3>
      <p>Total Students: {attendanceData.totalStudents}</p>
      <p>Present: {attendanceData.present}</p>
      <p>Absent: {attendanceData.absent}</p>
    </div>
  );
};

export default OverallAttendance;
