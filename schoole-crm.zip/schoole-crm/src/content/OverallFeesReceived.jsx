import React from 'react';
import '../Styles/OverallFeesReceived.css'

const OverallFeesReceived = () => {
  // Mock data for demonstration
  const feesData = {
    totalFees: 500000,
    feesCollected: 450000,
    pendingFees: 50000,
  };

  return (
    <div className="overall-fees-received">
      <h3>Overall Fees Received</h3>
      <p>Total Fees: ₹{feesData.totalFees}</p>
      <p>Fees Collected: ₹{feesData.feesCollected}</p>
      <p>Pending Fees: ₹{feesData.pendingFees}</p>
    </div>
  );
};

export default OverallFeesReceived;
