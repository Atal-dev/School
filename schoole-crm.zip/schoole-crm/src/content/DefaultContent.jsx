import React from 'react';
import OverallAttendance from './OverallAttendance';
import NoticeBoard from './NoticeBoard';
import BirthdaySection from './BirthdaySection';
import OverallFeesReceived from './OverallFeesReceived';
import '../Styles/DefaultContent.css';
import {Link} from 'react-router-dom';

const DefaultContent = () => {
  return (
    <>
    <div className="default-content">
      <h2>Dashboard Overview</h2>
      <div className="dashboard-sections">
        
       <Link to='/ClassAttendance'> <OverallAttendance /> </Link>
       {/* <OverallAttendance /> */}
        <NoticeBoard />
        <BirthdaySection />
        <OverallFeesReceived />
      </div>
    </div>
    </>
  );
};

export default DefaultContent;
