// AddTeacher.js
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addTeacher } from '../redux/teacherSlice';
// import '../Styles/AddTeacher.css';

const AddTeacher = () => {
  const dispatch = useDispatch();
  const [teacherName, setTeacherName] = useState('');
  const [subject, setSubject] = useState('');
  const [teacherId, setTeacherId] = useState('');
  const [qualification, setQualification] = useState('');
  const [age, setAge] = useState('');
  const [experience, setExperience] = useState('');
  const [assignedClass, setAssignedClass] = useState('');

  // Fetch available classes from Redux (assuming they are stored there)
  const classes = useSelector((state) => state.student.studentsData.map(cls => cls.className));

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!teacherName || !subject || !teacherId || !qualification || !age || !experience 
        // || !assignedClass 
    ) {
      alert('Please fill all fields');
      return;
    }

    // Dispatch action to add teacher
    dispatch(addTeacher({
      id: teacherId,
      name: teacherName,
      subject,
      qualification,
      age,
      experience,
      assignedClass
    }));

    // Clear form fields after submission
    setTeacherName('');
    setSubject('');
    setTeacherId('');
    setQualification('');
    setAge('');
    setExperience('');
    setAssignedClass('');
    alert('Teacher added successfully');
  };

  return (
    <div className="add-teacher-form">
      <h2>Add Teacher</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Teacher ID:</label>
          <input
            type="text"
            value={teacherId}
            onChange={(e) => setTeacherId(e.target.value)}
            placeholder="Enter Teacher ID"
          />
        </div>
        <div>
          <label>Teacher Name:</label>
          <input
            type="text"
            value={teacherName}
            onChange={(e) => setTeacherName(e.target.value)}
            placeholder="Enter Teacher Name"
          />
        </div>
        <div>
          <label>Subject:</label>
          <input
            type="text"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="Enter Subject"
          />
        </div>
        <div>
          <label>Qualification:</label>
          <input
            type="text"
            value={qualification}
            onChange={(e) => setQualification(e.target.value)}
            placeholder="Enter Qualification"
          />
        </div>
        <div>
          <label>Age:</label>
          <input
            type="number"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            placeholder="Enter Age"
          />
        </div>
        <div>
          <label>Experience (Years):</label>
          <input
            type="number"
            value={experience}
            onChange={(e) => setExperience(e.target.value)}
            placeholder="Enter Experience"
          />
        </div>
        <div>
          {/* <label>Assigned Class:</label>
          <select
            value={assignedClass}
            onChange={(e) => setAssignedClass(e.target.value)}
          >
            <option value="">Select Class</option>
            {classes.map((cls) => (
              <option key={cls} value={cls}>
                {cls}
              </option>
            ))}
          </select> */}
        </div>
        <button type="submit">Add Teacher</button>
      </form>
    </div>
  );
};

export default AddTeacher;
