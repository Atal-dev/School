import React from 'react';

const ClassSectionContent = () => {
  return (
    <div>
      {/* <h2>Class & Section Information</h2>
      <p>This is the content for Class & Section submenu.</p> */}

      {/* <img src="https://custom-images.strikinglycdn.com/res/hrscywv4p/image/upload/c_limit,fl_lossy,h_9000,w_1200,f_auto,q_auto/8103728/142995_42655.png" alt="" height={'100%'} width={'100%'} /> */}

      <h1 style={{textAlign:'center',justifyContent:'center'}}>Page not ready<br/>Comming Soon.....</h1>
    </div>
  );
};

export default ClassSectionContent;
