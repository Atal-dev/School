import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addStudent } from '../redux/studentsSlice'; // Adjust the import path based on your project structure
import '../Styles/AddStudent.css'

const classData = [
    { name: 'Class 1', sections: ['A', 'B'] },
    { name: 'Class 2', sections: ['A', 'B'] },
    { name: 'Class 3', sections: ['A', 'B', 'C'] },
    { name: 'Class 4', sections: ['A'] },
];

const AddStudent = () => {
    const [formData, setFormData] = useState({
        className: '',
        section: '',
        name: '',
        admissionNumber: '',
        rollNumber: '',
        fatherName: '',
        dob: '',
        gender: '',
        mobileNo: '',
        dateOfAdmission: '',
        religion: '',
        caste: ''
    });

    const dispatch = useDispatch();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const { className, section, ...studentDetails } = formData;
        dispatch(addStudent({ className, newStudent: { section, ...studentDetails } }));
        setFormData({
            className: '',
            section: '',
            name: '',
            admissionNumber: '',
            rollNumber: '',
            fatherName: '',
            dob: '',
            gender: '',
            mobileNo: '',
            dateOfAdmission: '',
            religion: '',
            caste: ''
        });
    };

    return (
        <form onSubmit={handleSubmit}>
            <div>
                <label>Class:</label>
                <select
                    name="className"
                    value={formData.className}
                    onChange={handleChange}
                    required
                >
                    <option value="">Select Class</option>
                    {classData.map((cls, index) => (
                        <option key={index} value={cls.name}>{cls.name}</option>
                    ))}
                </select>
            </div>
            <div>
                <label>Section:</label>
                <select
                    name="section"
                    value={formData.section}
                    onChange={handleChange}
                    disabled={!formData.className} // Disable until class is selected
                >
                    <option value="">Select Section</option>
                    {formData.className &&
                        classData.find(cls => cls.name === formData.className).sections.map((sec, index) => (
                            <option key={index} value={sec}>{sec}</option>
                        ))
                    }
                </select>
            </div>
            <div>
                <label>Student Name:</label>
                <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                />
            </div>
            <div>
                <label>Admission Number:</label>
                <input
                    type="text"
                    name="admissionNumber"
                    value={formData.admissionNumber}
                    onChange={handleChange}
                    required
                />
            </div>
            <div>
                <label>Roll Number:</label>
                <input
                    type="number"
                    name="rollNumber"
                    value={formData.rollNumber}
                    onChange={handleChange}
                    required
                />
            </div>
            <div>
                <label>Father's Name:</label>
                <input
                    type="text"
                    name="fatherName"
                    value={formData.fatherName}
                    onChange={handleChange}
                    required
                />
            </div>
            <div>
                <label>Date of Birth:</label>
                <input
                    type="date"
                    name="dob"
                    value={formData.dob}
                    onChange={handleChange}
                    required
                />
            </div>
            <div>
                <label>Gender:</label>
                <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleChange}
                    required
                >
                    <option value="">Select Gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                </select>
            </div>
            <div>
                <label>Mobile Number:</label>
                <input
                    type="text"
                    name="mobileNo"
                    value={formData.mobileNo}
                    onChange={handleChange}
                    required
                />
            </div>
            <div>
                <label>Date of Admission:</label>
                <input
                    type="date"
                    name="dateOfAdmission"
                    value={formData.dateOfAdmission}
                    onChange={handleChange}
                    required
                />
            </div>
            <div>
                <label>Religion:</label>
                <select
                    name="religion"
                    value={formData.religion}
                    onChange={handleChange}
                    required
                >
                    <option value="">Select Religion</option>
                    <option value="Hindu">Hindu</option>
                    <option value="Muslim">Muslim</option>
                    <option value="Christian">Christian</option>
                    <option value="Sikh">Sikh</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div>
                <label>Caste:</label>
                <select
                    name="caste"
                    value={formData.caste}
                    onChange={handleChange}
                    required
                >
                    <option value="">Select Caste</option>
                    <option value="General">General</option>
                    <option value="OBC">OBC</option>
                    <option value="SC">SC</option>
                    <option value="ST">ST</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <button className='addStuBtn' type="submit">Add Student</button>
        </form>
    );
};

export default AddStudent;
