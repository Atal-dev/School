import React from 'react';
import '../Styles/NoticeBoard.css'

const NoticeBoard = () => {
  // Mock notices for demonstration
  const notices = [
    'School will remain closed on Friday due to maintenance.',
    'Annual Sports Day is scheduled for next month.',
    'Submit your science project by the end of this week.',
  ];

  return (
    <div className="notice-board">
      <h3>Notice Board</h3>
      <ul>
        {notices.map((notice, index) => (
          <li key={index}>{notice}</li>
        ))}
      </ul>
    </div>
  );
};

export default NoticeBoard;
