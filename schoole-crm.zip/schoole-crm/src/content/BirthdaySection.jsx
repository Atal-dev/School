import React from 'react';
import { useSelector } from 'react-redux';
import '../Styles/BirthdaySection.css'; // Ensure you have a CSS file for styling

const BirthdaySection = () => {
  const students = useSelector(state => state.student);

  // Check if students is defined and has studentsData
  const { studentsData = [] } = students || {};

  // Get today's date in 'MM-DD' format
  const today = new Date();
  const todayMMDD = today.toISOString().slice(5, 10); // format 'MM-DD'

  // Get students with today's birthday (only matching month and day)
  const birthdayStudents = studentsData
    .flatMap(cls => Object.values(cls.sections).flat())
    .filter(student => student.dob.slice(5) === todayMMDD); // Filter by birthday (MM-DD)

  // Debugging Output
  // console.log('Today\'s Date (MM-DD):', todayMMDD); // Log today's date
  // console.log('All Students:', studentsData); // Log all students
  // console.log('Birthday Students:', birthdayStudents); // Log birthday students

  return (
    <div className="birthday-section">
      <h3>Birthday Section</h3>
      {birthdayStudents.length > 0 ? (
        <ul>
          {birthdayStudents.map(student => (
            <li key={student.id}>
              🎂 Happy Birthday, {student.name}!
            </li>
          ))}
        </ul>
      ) : (
        <p>No birthdays today.</p>
      )}
    </div>
  );
};

export default BirthdaySection;
