// MarkAttendance.js
import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { markAttendanceSubmitted } from '../redux/studentsSlice';
import { markTeacherAttendanceSubmitted } from '../redux/teacherSlice';
import '../Styles/MarkAttendance.css';

const MarkAttendance = () => {
  const dispatch = useDispatch();
  const { studentsData } = useSelector((state) => state.student);
  const { teachersData } = useSelector((state) => state.teacher);
  const [selectedType, setSelectedType] = useState('student');
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedSection, setSelectedSection] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [attendance, setAttendance] = useState({});

  const handleTypeChange = (type) => {
    setSelectedType(type);
    setSelectedClass('');
    setSelectedSection('');
    setSelectedDate('');
  };

  const handleClassChange = (e) => {
    setSelectedClass(e.target.value);
    setSelectedSection('');
  };

  const handleSectionChange = (e) => {
    setSelectedSection(e.target.value);
  };

  const handleDateChange = (e) => {
    setSelectedDate(e.target.value);
  };

  const toggleAttendance = (id) => {
    if (!selectedClass && selectedType === 'student') {
      alert('Please select a class, section, and date first');
      return;
    }

    setAttendance((prev) => {
      const key = `${selectedType}-${selectedClass || 'staff'}-${selectedSection || 'none'}-${selectedDate}`;
      const newAttendance = { ...prev[key] };
      newAttendance[id] = !newAttendance[id];
      return { ...prev, [key]: newAttendance };
    });
  };

  const handleSubmit = () => {
    if (!selectedDate) {
      alert('Please select a date before submitting');
      return;
    }

    if (selectedType === 'student') {
      if (!selectedClass || !selectedSection) {
        alert('Please select a class and section');
        return;
      }
      dispatch(markAttendanceSubmitted({
        type: selectedType,
        className: selectedClass,
        section: selectedSection,
        date: selectedDate
      }));
    } else {
      dispatch(markTeacherAttendanceSubmitted({ date: selectedDate }));
    }

    alert(`${selectedType.charAt(0).toUpperCase() + selectedType.slice(1)} attendance submitted successfully`);
  };

  const getDataList = () => {
    return selectedType === 'student' ? getStudents() : teachersData;
  };

  const getStudents = () => {
    const classData = studentsData.find((cls) => cls.className === selectedClass);
    return classData ? classData.sections[selectedSection] || [] : [];
  };

  const getSections = () => {
    const classData = studentsData.find((cls) => cls.className === selectedClass);
    return classData ? Object.keys(classData.sections) : [];
  };

  const isPersonPresent = (id) => {
    const key = `${selectedType}-${selectedClass || 'staff'}-${selectedSection || 'none'}-${selectedDate}`;
    return attendance[key]?.[id] || false;
  };

  return (
    <div className="attendance-component">
      <h2>Attendance Marking</h2>
      <div className="toggle-buttons">
        <button onClick={() => handleTypeChange('student')} className={selectedType === 'student' ? 'active' : ''}>
          Student
        </button>
        <button onClick={() => handleTypeChange('staff')} className={selectedType === 'staff' ? 'active' : ''}>
          Staff
        </button>
      </div>
      <div>
        {selectedType === 'student' && (
          <>
            <label>
              Choose Class:
              <select value={selectedClass} onChange={handleClassChange}>
                <option value="">Select Class</option>
                {studentsData.map((cls) => (
                  <option key={cls.className} value={cls.className}>
                    {cls.className}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Choose Section:
              <select value={selectedSection} onChange={handleSectionChange} disabled={!selectedClass}>
                <option value="">Select Section</option>
                {getSections().map((section) => (
                  <option key={section} value={section}>
                    {section}
                  </option>
                ))}
              </select>
            </label>
          </>
        )}
        <label>
          Choose Date:
          <input type="date" value={selectedDate} onChange={handleDateChange} />
        </label>
      </div>

      <div className="list-container">
        <h3>{selectedType.charAt(0).toUpperCase() + selectedType.slice(1)} List</h3>
        <ul>
          {getDataList().map((person) => (
            <li key={person.id}>
              {person.name} {selectedType === 'student' && `(DOB: ${person.dob})`}
              <label>
                <input
                  type="checkbox"
                  checked={isPersonPresent(person.id)}
                  onChange={() => toggleAttendance(person.id)}
                />
                Present
              </label>
            </li>
          ))}
        </ul>
        <button className='sbutton' onClick={handleSubmit}>Submit</button>
      </div>
    </div>
  );
};

export default MarkAttendance;
