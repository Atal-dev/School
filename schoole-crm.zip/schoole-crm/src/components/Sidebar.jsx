import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setActiveMenu, setActiveSubmenu } from '../redux/dashboardSlice';
import './Sidebar.css'

const Sidebar = () => {
  const dispatch = useDispatch();
  const { activeMenu } = useSelector(state => state.dashboard);

  return (
    <aside className="sidebar">
      <ul>
        {/* Menu: Academic */}
        <li>
          <button onClick={() => dispatch(setActiveMenu('academic'))}>
            Academic
          </button>
          {activeMenu === 'academic' && (
            <ul>
              <li>
                <button onClick={() => dispatch(setActiveSubmenu('Dashboard'))}>
                  Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => dispatch(setActiveSubmenu('classSection'))}>
                  Class & Section
                </button>
              </li>
              <li>
                <button onClick={() => dispatch(setActiveSubmenu('subjectModules'))}>
                  Subject & Modules
                </button>
              </li>
              <li>
                <button onClick={() => dispatch(setActiveSubmenu('markAttendance'))}>
                  Mark Attendance
                </button>
              </li>
              <li>
                <button onClick={() => dispatch(setActiveSubmenu('AddStudent'))}>
                  Add Student
                </button>
              </li>
              <li>
                <button onClick={() => dispatch(setActiveSubmenu('AddTeacher'))}>
                  Add Teacher
                </button>
              </li>
              <li>
                <button onClick={() => dispatch(setActiveSubmenu('Assignment'))}>
                  Assignment
                </button>
              </li>
              <li>
                <button onClick={() => dispatch(setActiveSubmenu('Exam'))}>
                  Exam
                </button>
              </li>
              <li>
                <button onClick={() => dispatch(setActiveSubmenu('LessonPlanner'))}>
                  Lesson planner
                </button>
              </li>
              <li>
                <button onClick={() => dispatch(setActiveSubmenu('Calender'))}>
                  Calender
                </button>
              </li>
            </ul>
          )}
        </li>

        <li>
          <button onClick={() => dispatch(setActiveMenu('Communicate'))}>
            Communicate
          </button>
          {activeMenu === 'Communicate' && (
            <ul>
              <li>
                <button onClick={() => dispatch(setActiveSubmenu('classSection'))}>
                  Class & Section
                </button>
              </li>
              <li>
                <button onClick={() => dispatch(setActiveSubmenu('subjectModules'))}>
                  Subject & Modules
                </button>
              </li>
            </ul>
          )}
        </li>

        <li>
          <button onClick={() => dispatch(setActiveMenu('HR'))}>
            HR
          </button>
          {activeMenu === 'HR' && (
            <ul>
              <li>
                <button onClick={() => dispatch(setActiveSubmenu('classSection'))}>
                  Class & Section
                </button>
              </li>
            </ul>
          )}
        </li>

        <li>
          <button onClick={() => dispatch(setActiveMenu('Finance'))}>
            Finance
          </button>
          {activeMenu === 'Finance' && (
            <ul>
              <li>
                <button onClick={() => dispatch(setActiveSubmenu('classSection'))}>
                  Class & Section
                </button>
              </li>
            </ul>
          )}
        </li>

        <li>
          <button onClick={() => dispatch(setActiveMenu('Misc'))}>
            Misc
          </button>
          {activeMenu === 'Misc' && (
            <ul>
              <li>
                <button onClick={() => dispatch(setActiveSubmenu('classSection'))}>
                  Class & Section
                </button>
              </li>
            </ul>
          )}
        </li>

        {/* Add more menus here, following the same pattern */}
      </ul>
    </aside>
  );
};

export default Sidebar;
