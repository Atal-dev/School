import React from 'react';
import { useSelector } from 'react-redux';
import ClassSectionContent from '../content/ClassSectionContent';
import MarkAttendance from '../content/MarkAttendance'
import DefaultContent from '../content/DefaultContent'
import ClassAttendanceStatus from '../content/ClassAttendanceStatus'



import './MainContent.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import AddStudent from '../content/AddStudent';
import AddTeacher from '../content/AddTeacher';

const MainContent = () => {
  const { activeSubmenu } = useSelector(state => state.dashboard);


  let content;
  switch (activeSubmenu) {
    case 'Dashboard':
      content = <DefaultContent/>;
      break;
    case 'classSection':
      content = <ClassSectionContent />;
      break;
    case 'subjectModules':
      content = <ClassSectionContent />;
      break;
    case 'markAttendance':
      content = <MarkAttendance/>;
      break;
    case 'AddStudent':
      content = <AddStudent/>;
      break;
    case 'AddTeacher':
      content = <AddTeacher/>;
      break;  
    case 'Assignment':
      content = <ClassSectionContent />;
      break;
    case 'Exam':
      content = <ClassSectionContent />;
      break;
    case 'LessonPlanner':
      content = <ClassSectionContent />;
      break;
    case 'Calender':
       content = <ClassSectionContent />;
       break;
    // Add more cases for other submenu items
    default:
      content = <DefaultContent/>;
  }

  return (
    <main className="main-content">
      <BrowserRouter>
       <Routes>
        <Route path='/' element={content} />
        <Route path='/ClassAttendance' element={<ClassAttendanceStatus/>} />
      </Routes>
      </BrowserRouter>

    </main>
    
  );
};

export default MainContent;
