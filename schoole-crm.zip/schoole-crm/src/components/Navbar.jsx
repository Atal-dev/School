import React from 'react';
import './Navbar.css'

const Navbar = ({ onToggleSidebar }) => {
  return (
    <nav className="navbar">
      <button className="toggle-btn" onClick={onToggleSidebar}>=</button>
      <h1>School Management CRM</h1>
    </nav>
  );
};

export default Navbar;
